# ClearFlow Drainage — Google Ads practice website

A responsive static lead-generation website suitable for publishing with GitHub Pages.

## Files
- `index.html` — landing page and lead form
- `thank-you.html` — form confirmation page
- `privacy.html` — starter privacy policy (customize before use)
- `styles.css` — responsive styling

## Publish on GitHub Pages
1. Create a GitHub repository, e.g. `google-ads-practice-site`.
2. Upload all four files to the repository root (not inside an extra folder).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and open the URL shown on the Pages screen.

## Before using the form
1. Open `index.html` and replace `YOUR_EMAIL@example.com` in the form `action` with the email address that should receive leads, e.g. `https://formsubmit.co/you@example.com`.
2. Replace all demo contact details: `01234 567890`, `+441234567890`, and `hello@example.com` with your actual business contact details. Search all files for these placeholders.
3. Submit a test form. FormSubmit may require email activation/confirmation on first use. Confirm the email arrives and that the redirect to `thank-you.html` works. The form processor must be configured before the form is live.
4. Replace the stock photos and sample service/business claims with accurate assets and details. Check image provider terms before commercial use.
5. Customize the privacy policy and review applicable privacy/consent requirements.

## Google Ads and GTM conversion tracking
- Create a Google Tag Manager container and install its official snippets in the `<head>` and immediately after the opening `<body>` tag on **every page**. The body snippet is not included here because GTM gives you the exact code for your container.
- Add the Google Ads conversion tag through GTM and use a page-view trigger for `thank-you.html` only after you have verified that successful form submissions reliably reach that page. Avoid counting visits to the thank-you page that did not follow a real submission.
- Set up a separate click-to-call conversion if useful. For a basic click trigger, match the link click URL beginning with `tel:`; verify implementation with GTM Preview and Google Ads diagnostics.
- A thank-you-page view is a useful practice setup, but client-side redirects alone are not perfect proof that a lead was delivered. Test end-to-end before relying on the data.
- Do not paste real Google Ads IDs into a public repository if your organization treats them as sensitive; use your account's recommended implementation practices.

## Notes
GitHub Pages only serves static files. This template does not include a server or database. FormSubmit is a third-party form service; review its terms, privacy and spam protection before use. This demo template is not a guarantee of Google Ads approval or performance.
